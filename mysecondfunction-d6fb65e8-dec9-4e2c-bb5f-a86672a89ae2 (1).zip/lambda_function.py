import pymongo
import json
from bson import ObjectId
import requests

def make_api_call_for_interests(interests):
    access_key = "20bde9fcfaaa00a9750fee076eceaa2c"
    base_url = "http://api.mediastack.com/v1/news"
    countries = "in"
    limit = 10
    api_results = []

    try:
        for user in interests:
            user_id = user["_id"]
            user_interests = user.get("interests", [])

            user_data = {
                "id": user_id,
                "interests": user_interests,
                "news": []  
            }

            for interest in user_interests:
                params = {
                    "access_key": access_key,
                    "keywords": interest,
                    "countries": countries,
                    "limit": limit,
                }

                response = requests.get(base_url, params=params)

                if response.status_code == 200:
                    news_data = response.json()
                    filtered_articles = []
                    for article in news_data["data"]:
                        if article.get("image") and article["image"] != "null":
                            filtered_articles.append(article)
                    if filtered_articles:
                        user_data["news"].append({
                            "interest": interest,
                            "articles": filtered_articles
                        })
                else:
                    user_data["news"].append({
                        "interest": interest,
                        "error": f"Failed to fetch news for interest '{interest}'"
                    })

            api_results.append(user_data)
    
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": str(e)
            })
        }

    return api_results

def lambda_handler(event, context):
    
    mongo_uri = "mongodb+srv://interestNet:vBFo4fS3b3yD4rEi@minor.ioilrpi.mongodb.net/"

    database_name = "test"  
    collection_name = "users"  

    
    ssl_options = {
        'ssl': True,
    }

    
    try:
        client = pymongo.MongoClient(mongo_uri, **ssl_options)
        db = client[database_name]
        collection = db[collection_name]

        users_with_interests = collection.find({}, {"_id": 1, "interests": 1})

        
        users_list = []
        for user in users_with_interests:
            user["_id"] = str(user["_id"])  # Convert ObjectId to string
            users_list.append(user)

        
        client.close()

        
        api_results = make_api_call_for_interests(users_list)

        
        response = {
            "statusCode": 200,
            "body": json.dumps({
                "users": api_results
            })
        }
        return response
    except Exception as e:
        
        response = {
            "statusCode": 500,
            "body": json.dumps({
                "error": str(e)
            })
        }
        return response
